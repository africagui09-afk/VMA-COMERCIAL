import React, { useEffect, useMemo, useState } from 'react';
import { Header } from './components/Header';
import { PDV } from './components/PDV';
import { StockManagement } from './components/StockManagement';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { SalesHistory } from './components/SalesHistory';
import { PDFReportModal } from './components/PDFReportModal';
import { LoginModal } from './components/LoginModal';
import { SupabaseModal } from './components/SupabaseModal';
import { Expense, Product, Sale, User } from './types';
import {
  getCurrentUser,
  getExpenses,
  getProducts,
  getSales,
  initStorage,
  setCurrentUser,
} from './lib/storage';
import { formatDateTime, formatKz, getPaymentMethodName } from './lib/formatters';
import { Printer, X } from 'lucide-react';

export default function App() {
  const [currentUser, setUserState] = useState<User>(() => {
    initStorage();
    return getCurrentUser();
  });

  const [activeView, setActiveView] = useState<'pdv' | 'estoque' | 'dashboard' | 'vendas'>('pdv');
  const [products, setProducts] = useState<Product[]>([]);
  const [sales, setSales] = useState<Sale[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);

  // Modals
  const [isLoginOpen, setIsLoginOpen] = useState<boolean>(false);
  const [isSupabaseOpen, setIsSupabaseOpen] = useState<boolean>(false);
  const [isPdfOpen, setIsPdfOpen] = useState<boolean>(false);
  const [reprintSale, setReprintSale] = useState<Sale | null>(null);

  // Load data
  const refreshData = () => {
    setProducts(getProducts());
    setSales(getSales());
    setExpenses(getExpenses());
  };

  useEffect(() => {
    initStorage();
    refreshData();
  }, []);

  // Enforce role restrictions
  const handleNavigate = (view: 'pdv' | 'estoque' | 'dashboard' | 'vendas') => {
    if (view === 'dashboard' && currentUser.role !== 'ADMINISTRADOR') {
      alert('Acesso Restrito: O Dashboard Analítico é exclusivo para Administradores.');
      return;
    }
    if (view === 'estoque' && currentUser.role === 'VENDEDOR') {
      alert('Acesso Restrito: Vendedores têm acesso exclusivo à Frente de Caixa.');
      return;
    }
    setActiveView(view);
  };

  const handleUserChange = (user: User) => {
    setUserState(user);
    setCurrentUser(user);
    // If downgraded from Admin/Gerente to Vendedor while in restricted view, return to PDV
    if (user.role === 'VENDEDOR' && (activeView === 'estoque' || activeView === 'dashboard')) {
      setActiveView('pdv');
    } else if (user.role === 'GERENTE' && activeView === 'dashboard') {
      setActiveView('estoque');
    }
  };

  // Red alert count for products below minimum stock
  const stockAlertCount = useMemo(() => {
    return products.filter((p) => p.stock <= p.minStock).length;
  }, [products]);

  return (
    <div className="min-h-screen flex flex-col bg-[#0a0d14] text-zinc-100 selection:bg-emerald-600 selection:text-white font-sans">
      {/* Universal Top Header with Back button, Online status, Sync, Role & Seller Daily Meter */}
      <Header
        currentUser={currentUser}
        activeView={activeView}
        onNavigate={handleNavigate}
        onOpenLogin={() => setIsLoginOpen(true)}
        onOpenSupabaseModal={() => setIsSupabaseOpen(true)}
        onExportPDF={() => setIsPdfOpen(true)}
        stockAlertCount={stockAlertCount}
      />

      {/* Main View Container */}
      <main className="flex-1 flex flex-col min-h-0">
        {activeView === 'pdv' && (
          <PDV
            currentUser={currentUser}
            products={products}
            onRefreshData={refreshData}
          />
        )}

        {activeView === 'estoque' && (
          <StockManagement
            currentUser={currentUser}
            products={products}
            onRefreshData={refreshData}
            onBackToPDV={() => setActiveView('pdv')}
            onExportPDF={() => setIsPdfOpen(true)}
          />
        )}

        {activeView === 'dashboard' && (
          <AnalyticsDashboard
            currentUser={currentUser}
            sales={sales}
            products={products}
            expenses={expenses}
            onRefreshData={refreshData}
            onBackToPDV={() => setActiveView('pdv')}
            onExportPDF={() => setIsPdfOpen(true)}
          />
        )}

        {activeView === 'vendas' && (
          <SalesHistory
            currentUser={currentUser}
            sales={sales}
            onRefreshData={refreshData}
            onBackToPDV={() => setActiveView('pdv')}
            onReprintReceipt={(sale) => setReprintSale(sale)}
          />
        )}
      </main>

      {/* MODALS */}
      {/* 1. Login & Role Switcher */}
      {isLoginOpen && (
        <LoginModal
          currentUser={currentUser}
          onSelectUser={handleUserChange}
          onClose={() => setIsLoginOpen(false)}
        />
      )}

      {/* 2. Supabase & Offline-First Sync Settings */}
      {isSupabaseOpen && (
        <SupabaseModal
          onClose={() => setIsSupabaseOpen(false)}
          onRefreshData={refreshData}
        />
      )}

      {/* 3. Executive A4 PDF Report */}
      {isPdfOpen && (
        <PDFReportModal
          currentUser={currentUser}
          sales={sales}
          products={products}
          expenses={expenses}
          onClose={() => setIsPdfOpen(false)}
        />
      )}

      {/* 4. Reprint Receipt Modal */}
      {reprintSale && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="bg-[#111620] border border-zinc-700 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col max-h-[95vh]">
            <div className="p-4 bg-[#0e131b] border-b border-zinc-800 flex items-center justify-between">
              <h3 className="text-sm font-bold text-white">Reimpressão de Talão</h3>
              <button
                type="button"
                onClick={() => setReprintSale(null)}
                className="text-zinc-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto">
              <div id="receipt-print-area" className="bg-white text-zinc-950 p-5 rounded-lg font-mono text-xs shadow-inner space-y-3">
                <div className="text-center border-b border-zinc-300 pb-2">
                  <h2 className="text-base font-black tracking-tight uppercase">KwanzaPOS Loja Comercial</h2>
                  <p className="text-[10px] text-zinc-600">NIF: 5418029310 | Luanda, Angola</p>
                  <div className="mt-1 font-bold text-xs">2ª VIA / REIMPRESSÃO</div>
                  <div className="text-[11px] font-bold text-zinc-800">{reprintSale.invoiceNumber}</div>
                </div>

                <div className="text-[10px] space-y-0.5 border-b border-zinc-200 pb-2">
                  <div className="flex justify-between">
                    <span>Data da Venda:</span>
                    <span>{formatDateTime(reprintSale.createdAt)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Operador:</span>
                    <span>{reprintSale.sellerName} ({reprintSale.sellerRole})</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cliente:</span>
                    <span>{reprintSale.customerName || 'Consumidor Final'}</span>
                  </div>
                </div>

                <div className="space-y-1 border-b border-zinc-300 pb-2">
                  {reprintSale.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between text-[10px]">
                      <span className="truncate max-w-[140px]">{item.productName}</span>
                      <span>{item.quantity} × {formatKz(item.unitPrice)}</span>
                      <span className="font-bold">{formatKz(item.total)}</span>
                    </div>
                  ))}
                </div>

                <div className="space-y-1 text-[11px]">
                  <div className="flex justify-between font-black text-sm pt-1">
                    <span>TOTAL PAGO:</span>
                    <span>{formatKz(reprintSale.total)}</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-zinc-700">
                    <span>Forma de Pagamento:</span>
                    <span>{getPaymentMethodName(reprintSale.payments[0]?.method || 'DINHEIRO')}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-[#0e131b] border-t border-zinc-800 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => window.print()}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-2"
              >
                <Printer className="w-4 h-4" />
                <span>Imprimir Talão</span>
              </button>
              <button
                type="button"
                onClick={() => setReprintSale(null)}
                className="px-4 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
