import React, { useMemo, useState } from 'react';
import {
  AlertCircle,
  AlertTriangle,
  Barcode,
  CheckCircle2,
  ChevronDown,
  CreditCard,
  DollarSign,
  Minus,
  Package,
  Plus,
  Printer,
  Receipt,
  RotateCcw,
  Search,
  ShoppingCart,
  Trash2,
  TrendingUp,
  User as UserIcon,
  X,
  Zap,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { CartItem, PaymentMethod, Product, Sale, User } from '../types';
import { formatDateTime, formatKz, getPaymentMethodName } from '../lib/formatters';
import {
  checkSellerLimit,
  createSale,
  getSellerDailyTotal,
  SELLER_DAILY_LIMIT,
} from '../lib/storage';

interface PDVProps {
  currentUser: User;
  products: Product[];
  onRefreshData: () => void;
}

export const PDV: React.FC<PDVProps> = ({ currentUser, products, onRefreshData }) => {
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('TODOS');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [discountTotal, setDiscountTotal] = useState<number>(0);
  const [customerName, setCustomerName] = useState<string>('');
  const [customerNif, setCustomerNif] = useState<string>('999999999'); // NIF Consumidor Final em Angola

  // Mobile cart view toggle
  const [mobileCartOpen, setMobileCartOpen] = useState<boolean>(false);

  // Checkout modal
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('MULTICAIXA');
  const [cashReceived, setCashReceived] = useState<string>('');
  const [checkoutError, setCheckoutError] = useState<string | null>(null);

  // Completed sale receipt modal
  const [completedSale, setCompletedSale] = useState<Sale | null>(null);

  // Categories list
  const categories = useMemo(() => {
    const list = Array.from(new Set(products.map((p) => p.category))).filter(Boolean);
    return ['TODOS', ...list];
  }, [products]);

  // Filtered products
  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchSearch =
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.barcode.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.category.toLowerCase().includes(searchTerm.toLowerCase());

      const matchCategory = selectedCategory === 'TODOS' || p.category === selectedCategory;

      return matchSearch && matchCategory;
    });
  }, [products, searchTerm, selectedCategory]);

  // Calculations
  const cartSubtotal = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  }, [cart]);

  const cartTotal = useMemo(() => {
    return Math.max(0, cartSubtotal - discountTotal);
  }, [cartSubtotal, discountTotal]);

  const totalItemsCount = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.quantity, 0);
  }, [cart]);

  // Daily limit check for seller
  const sellerDaily = useMemo(() => {
    if (currentUser.role !== 'VENDEDOR') return null;
    const currentTotal = getSellerDailyTotal(currentUser.id);
    const limit = SELLER_DAILY_LIMIT;
    const remaining = Math.max(0, limit - currentTotal);
    const isExceeded = currentTotal + cartTotal > limit;
    return { currentTotal, limit, remaining, isExceeded };
  }, [currentUser, cartTotal, completedSale]);

  // Cart actions
  const addToCart = (product: Product) => {
    if (product.stock <= 0) {
      alert(`O produto "${product.name}" encontra-se esgotado no estoque.`);
      return;
    }

    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        if (existing.quantity >= product.stock) {
          alert(`Quantidade máxima disponível em estoque (${product.stock} ${product.unit}) já adicionada ao carrinho.`);
          return prev;
        }
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prev, { product, quantity: 1, discount: 0 }];
      }
    });
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            if (newQty > item.product.stock) {
              alert(`Quantidade máxima em estoque: ${item.product.stock} ${item.product.unit}.`);
              return item;
            }
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart((prev) => prev.filter((item) => item.product.id !== productId));
  };

  const clearCart = () => {
    setCart([]);
    setDiscountTotal(0);
    setCheckoutError(null);
  };

  // Open checkout
  const handleOpenCheckout = () => {
    if (cart.length === 0) return;

    // Check seller limit
    if (currentUser.role === 'VENDEDOR') {
      const check = checkSellerLimit(currentUser.id, currentUser.role, cartTotal);
      if (!check.allowed) {
        setCheckoutError(check.error || 'Limite diário de 900.000 Kz excedido.');
        setIsCheckoutOpen(true);
        return;
      }
    }

    setCheckoutError(null);
    setCashReceived(String(cartTotal));
    setIsCheckoutOpen(true);
  };

  // Finish sale
  const handleFinishSale = () => {
    setCheckoutError(null);
    const numericCash = parseFloat(cashReceived) || 0;

    if (paymentMethod === 'DINHEIRO' && numericCash < cartTotal) {
      setCheckoutError(`Valor recebido (${formatKz(numericCash)}) é inferior ao total da venda (${formatKz(cartTotal)}).`);
      return;
    }

    const change = paymentMethod === 'DINHEIRO' ? Math.max(0, numericCash - cartTotal) : 0;
    const totalCost = cart.reduce((sum, item) => sum + item.product.costPrice * item.quantity, 0);

    const saleResult = createSale({
      items: cart.map((item) => ({
        productId: item.product.id,
        productName: item.product.name,
        quantity: item.quantity,
        unitPrice: item.product.price,
        costPrice: item.product.costPrice,
        discount: item.discount,
        total: item.product.price * item.quantity - item.discount,
      })),
      subtotal: cartSubtotal,
      discountTotal,
      total: cartTotal,
      totalCost,
      payments: [
        {
          method: paymentMethod,
          amount: cartTotal,
        },
      ],
      amountReceived: paymentMethod === 'DINHEIRO' ? numericCash : cartTotal,
      change,
      sellerId: currentUser.id,
      sellerName: currentUser.name,
      sellerRole: currentUser.role,
      customerName: customerName.trim() || 'Consumidor Final',
      customerNif: customerNif.trim() || '999999999',
    });

    if (!saleResult.success || !saleResult.sale) {
      setCheckoutError(saleResult.error || 'Erro ao processar venda.');
      return;
    }

    // Success! Trigger celebration confetti
    try {
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#10b981', '#059669', '#34d399', '#f59e0b'],
      });
    } catch {
      // safe fallback
    }

    setCompletedSale(saleResult.sale);
    setIsCheckoutOpen(false);
    clearCart();
    onRefreshData();
  };

  const handlePrintReceipt = () => {
    window.print();
  };

  const calculatedChange = useMemo(() => {
    if (paymentMethod !== 'DINHEIRO') return 0;
    const received = parseFloat(cashReceived) || 0;
    return Math.max(0, received - cartTotal);
  }, [cashReceived, cartTotal, paymentMethod]);

  return (
    <div className="flex-1 flex flex-col lg:flex-row h-[calc(100vh-100px)] overflow-hidden bg-[#0a0d14]">
      {/* LEFT / CENTER: Products Search & Grid */}
      <div className="flex-1 flex flex-col min-w-0 border-r border-zinc-800/80 overflow-hidden">
        {/* Search & Category Filter Bar */}
        <div className="p-3 sm:p-4 bg-[#0e131b] border-b border-zinc-800 flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar produto por nome, código de barras ou categoria..."
                className="w-full pl-10 pr-10 py-2.5 bg-zinc-900/90 border border-zinc-700/80 rounded-xl text-zinc-100 placeholder-zinc-500 text-sm focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
              />
              {searchTerm && (
                <button
                  type="button"
                  onClick={() => setSearchTerm('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-200"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Barcode Quick Badge */}
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-2.5 bg-zinc-900 border border-zinc-800 rounded-xl text-zinc-400 text-xs">
              <Barcode className="w-4 h-4 text-emerald-400" />
              <span>Leitor Ativo</span>
            </div>
          </div>

          {/* Categories Pill Navigation */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            {categories.map((cat) => {
              const active = selectedCategory === cat;
              return (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg whitespace-nowrap font-medium transition-all ${
                    active
                      ? 'bg-emerald-600 text-white shadow-sm font-semibold'
                      : 'bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
                  }`}
                >
                  {cat}
                </button>
              );
            })}
          </div>
        </div>

        {/* Products Grid */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 bg-[#0a0d14]">
          {filteredProducts.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-zinc-500 p-6 text-center">
              <Package className="w-12 h-12 text-zinc-600 mb-3" />
              <p className="text-base font-semibold text-zinc-400">Nenhum produto encontrado</p>
              <p className="text-xs text-zinc-500 mt-1 max-w-sm">
                Verifique o termo pesquisado ou selecione outra categoria.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-3 xl:grid-cols-4 gap-2.5 sm:gap-3.5">
              {filteredProducts.map((product) => {
                const isOutOfStock = product.stock <= 0;
                const isLowStock = !isOutOfStock && product.stock <= product.minStock;
                const inCartItem = cart.find((c) => c.product.id === product.id);

                return (
                  <button
                    key={product.id}
                    type="button"
                    onClick={() => !isOutOfStock && addToCart(product)}
                    disabled={isOutOfStock}
                    className={`relative text-left p-3 rounded-xl border flex flex-col justify-between transition-all duration-150 group ${
                      isOutOfStock
                        ? 'bg-zinc-950/40 border-zinc-800/80 opacity-50 cursor-not-allowed'
                        : isLowStock
                        ? 'bg-[#151212] border-rose-800/60 hover:border-rose-500 hover:bg-[#1c1414] active:scale-[0.98]'
                        : inCartItem
                        ? 'bg-[#0f1b16] border-emerald-600/70 hover:border-emerald-400 shadow-sm active:scale-[0.98]'
                        : 'bg-[#111620] border-zinc-800 hover:border-emerald-600/50 hover:bg-[#141b26] active:scale-[0.98]'
                    }`}
                  >
                    {/* In cart indicator pill */}
                    {inCartItem && (
                      <span className="absolute -top-2 -right-2 bg-emerald-500 text-zinc-950 text-[11px] font-black w-6 h-6 rounded-full flex items-center justify-center shadow-lg border-2 border-[#0a0d14]">
                        {inCartItem.quantity}
                      </span>
                    )}

                    {/* Stock Alert Badge */}
                    <div className="flex items-center justify-between gap-1 mb-2">
                      <span className="text-[10px] text-zinc-400 uppercase tracking-wider font-semibold truncate">
                        {product.category}
                      </span>
                      {isOutOfStock ? (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400 border border-zinc-700">
                          Esgotado
                        </span>
                      ) : isLowStock ? (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-700/80 flex items-center gap-1 animate-pulse">
                          <AlertTriangle className="w-2.5 h-2.5 text-rose-400" />
                          <span>Restam {product.stock}</span>
                        </span>
                      ) : (
                        <span className="text-[10px] font-medium text-emerald-400/90 bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-900/60">
                          Est: {product.stock} {product.unit}
                        </span>
                      )}
                    </div>

                    {/* Product Name */}
                    <h3 className="text-xs sm:text-sm font-semibold text-zinc-100 line-clamp-2 mb-2 group-hover:text-emerald-300 transition-colors">
                      {product.name}
                    </h3>

                    {/* Product Price in Kz */}
                    <div className="mt-auto pt-2 border-t border-zinc-800/80 flex items-baseline justify-between">
                      <span className="text-sm sm:text-base font-black text-emerald-400 tracking-tight">
                        {formatKz(product.price)}
                      </span>
                      <span className="text-[10px] text-zinc-400">/{product.unit}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* MOBILE FLOATING CART TRIGGER BAR */}
      <div className="lg:hidden p-3 bg-[#0e131b] border-t border-zinc-800 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-lg bg-emerald-600/30 text-emerald-400 flex items-center justify-center font-bold">
            <ShoppingCart className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs text-zinc-400">{totalItemsCount} {totalItemsCount === 1 ? 'item' : 'itens'}</div>
            <div className="text-sm font-bold text-emerald-400">{formatKz(cartTotal)}</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setMobileCartOpen(!mobileCartOpen)}
            className="px-3 py-2 bg-zinc-800 text-zinc-200 rounded-lg text-xs font-semibold hover:bg-zinc-700"
          >
            {mobileCartOpen ? 'Ver Produtos' : 'Abrir Carrinho'}
          </button>
          <button
            type="button"
            disabled={cart.length === 0}
            onClick={handleOpenCheckout}
            className="px-4 py-2 bg-emerald-600 disabled:opacity-50 text-white rounded-lg text-xs font-bold shadow-md hover:bg-emerald-500"
          >
            Cobrar {formatKz(cartTotal)}
          </button>
        </div>
      </div>

      {/* RIGHT: SHOPPING CART (Reactive Panel) */}
      <div
        className={`w-full lg:w-[420px] bg-[#0e131b] flex flex-col flex-shrink-0 z-30 lg:static fixed inset-x-0 bottom-0 top-[60px] lg:top-auto transition-transform duration-200 ${
          mobileCartOpen ? 'translate-y-0' : 'translate-y-full lg:translate-y-0'
        }`}
      >
        {/* Cart Header */}
        <div className="p-3 sm:p-4 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-emerald-400" />
            <h2 className="text-sm sm:text-base font-bold text-white">Carrinho da Venda</h2>
            <span className="px-2 py-0.5 rounded-full bg-zinc-800 text-emerald-400 text-xs font-bold border border-zinc-700">
              {totalItemsCount}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {cart.length > 0 && (
              <button
                type="button"
                onClick={clearCart}
                className="text-xs text-zinc-400 hover:text-rose-400 flex items-center gap-1 transition-colors"
                title="Limpar todos os produtos do carrinho"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Limpar</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => setMobileCartOpen(false)}
              className="lg:hidden p-1 text-zinc-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Customer Mini Bar */}
        <div className="px-3 sm:px-4 py-2 bg-zinc-950/60 border-b border-zinc-800 flex items-center gap-2 text-xs">
          <UserIcon className="w-3.5 h-3.5 text-zinc-400" />
          <input
            type="text"
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            placeholder="Cliente (Opcional - Padrão: Consumidor Final)"
            className="flex-1 bg-transparent text-zinc-200 placeholder-zinc-500 focus:outline-none text-xs"
          />
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-4 divide-y divide-zinc-800/60">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-zinc-500 p-6 text-center">
              <div className="w-12 h-12 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center mb-3">
                <ShoppingCart className="w-6 h-6 text-zinc-600" />
              </div>
              <p className="text-sm font-semibold text-zinc-400">Carrinho Vazio</p>
              <p className="text-xs text-zinc-500 mt-1 max-w-xs">
                Toque ou clique em qualquer produto do catálogo para adicionar à venda atual.
              </p>
            </div>
          ) : (
            cart.map((item) => {
              const itemTotal = item.product.price * item.quantity;
              return (
                <div key={item.product.id} className="py-3 flex items-center justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <h4 className="text-xs sm:text-sm font-semibold text-zinc-100 truncate">
                      {item.product.name}
                    </h4>
                    <div className="text-xs text-zinc-400 mt-0.5 flex items-center gap-2">
                      <span className="text-emerald-400 font-medium">{formatKz(item.product.price)}</span>
                      <span>× {item.quantity}</span>
                    </div>
                  </div>

                  {/* Quantity Controls */}
                  <div className="flex items-center gap-1.5 bg-zinc-900 border border-zinc-700/80 rounded-lg p-0.5">
                    <button
                      type="button"
                      onClick={() => updateQuantity(item.product.id, -1)}
                      className="w-7 h-7 rounded flex items-center justify-center text-zinc-300 hover:bg-zinc-800 active:scale-95 transition-all"
                      title="Diminuir quantidade"
                    >
                      <Minus className="w-3.5 h-3.5" />
                    </button>
                    <span className="w-6 text-center font-bold text-xs text-white">
                      {item.quantity}
                    </span>
                    <button
                      type="button"
                      onClick={() => updateQuantity(item.product.id, 1)}
                      className="w-7 h-7 rounded flex items-center justify-center text-zinc-300 hover:bg-zinc-800 active:scale-95 transition-all"
                      title="Aumentar quantidade"
                    >
                      <Plus className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Item Total & Remove */}
                  <div className="text-right min-w-[70px]">
                    <div className="text-xs sm:text-sm font-bold text-emerald-400">
                      {formatKz(itemTotal)}
                    </div>
                    <button
                      type="button"
                      onClick={() => removeFromCart(item.product.id)}
                      className="text-[10px] text-zinc-500 hover:text-rose-400 transition-colors mt-0.5"
                    >
                      Remover
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Cart Financial Summary & Checkout Action */}
        <div className="p-3 sm:p-4 bg-[#0b0e14] border-t border-zinc-800 flex flex-col gap-3">
          {/* Subtotal & Discounts */}
          <div className="space-y-1.5 text-xs text-zinc-400">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span className="font-semibold text-zinc-200">{formatKz(cartSubtotal)}</span>
            </div>

            {/* Optional Discount Input */}
            <div className="flex items-center justify-between gap-2 pt-1 border-t border-zinc-900">
              <span className="text-zinc-400">Desconto Geral (Kz):</span>
              <input
                type="number"
                min="0"
                max={cartSubtotal}
                value={discountTotal === 0 ? '' : discountTotal}
                onChange={(e) => setDiscountTotal(Math.max(0, parseFloat(e.target.value) || 0))}
                placeholder="0 Kz"
                className="w-24 px-2 py-1 bg-zinc-900 border border-zinc-800 rounded text-right text-xs text-amber-400 focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Total */}
            <div className="flex justify-between items-baseline pt-2 border-t border-zinc-800 text-white">
              <span className="text-sm font-bold">Total a Pagar:</span>
              <span className="text-lg sm:text-xl font-black text-emerald-400 tracking-tight">
                {formatKz(cartTotal)}
              </span>
            </div>
          </div>

          {/* Seller Daily Limit Warning if close or exceeded */}
          {sellerDaily && sellerDaily.isExceeded && (
            <div className="p-2.5 rounded-lg bg-rose-950/80 border border-rose-700/80 text-rose-300 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <strong>Atenção Vendedor:</strong> Esta venda ultrapassa seu limite diário de 900.000 Kz!
                (Disponível: {formatKz(sellerDaily.remaining)}).
              </div>
            </div>
          )}

          {/* Checkout Button */}
          <button
            type="button"
            disabled={cart.length === 0 || (sellerDaily?.isExceeded ?? false)}
            onClick={handleOpenCheckout}
            className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-500 hover:to-emerald-400 active:scale-[0.99] disabled:opacity-40 disabled:pointer-events-none text-zinc-950 font-black text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 transition-all cursor-pointer"
          >
            <Zap className="w-5 h-5 text-zinc-950 fill-current" />
            <span>Cobrar {formatKz(cartTotal)}</span>
          </button>
        </div>
      </div>

      {/* CHECKOUT MODAL */}
      {isCheckoutOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="bg-[#111620] border border-zinc-700 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            {/* Modal Header */}
            <div className="p-4 bg-[#0e131b] border-b border-zinc-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Receipt className="w-5 h-5 text-emerald-400" />
                <h3 className="text-base font-bold text-white">Fechamento de Venda Rápido</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsCheckoutOpen(false)}
                className="text-zinc-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <div className="p-4 sm:p-5 overflow-y-auto space-y-4">
              {/* Total Display */}
              <div className="p-4 rounded-xl bg-zinc-900/90 border border-zinc-800 text-center">
                <div className="text-xs text-zinc-400 uppercase tracking-wider font-semibold">
                  Valor Total a Pagar
                </div>
                <div className="text-2xl sm:text-3xl font-black text-emerald-400 mt-1">
                  {formatKz(cartTotal)}
                </div>
                <div className="text-xs text-zinc-500 mt-1">
                  {totalItemsCount} {totalItemsCount === 1 ? 'item' : 'itens'} no carrinho
                </div>
              </div>

              {/* Payment Methods */}
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-2">
                  Forma de Pagamento
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['MULTICAIXA', 'DINHEIRO', 'TRANSFERENCIA', 'MISTO'] as PaymentMethod[]).map((method) => {
                    const active = paymentMethod === method;
                    return (
                      <button
                        key={method}
                        type="button"
                        onClick={() => {
                          setPaymentMethod(method);
                          if (method === 'DINHEIRO') {
                            setCashReceived(String(cartTotal));
                          }
                        }}
                        className={`p-2.5 rounded-xl border text-center transition-all flex flex-col items-center justify-center gap-1 text-xs font-bold ${
                          active
                            ? 'bg-emerald-600 text-white border-emerald-400 shadow-md'
                            : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:bg-zinc-800'
                        }`}
                      >
                        {method === 'MULTICAIXA' && <CreditCard className="w-4 h-4" />}
                        {method === 'DINHEIRO' && <DollarSign className="w-4 h-4" />}
                        {method === 'TRANSFERENCIA' && <RotateCcw className="w-4 h-4" />}
                        {method === 'MISTO' && <Receipt className="w-4 h-4" />}
                        <span>{method === 'MULTICAIXA' ? 'TPA / MCX' : method === 'DINHEIRO' ? 'Dinheiro' : method === 'TRANSFERENCIA' ? 'Transf.' : 'Misto'}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Cash specific: Received and Change (Troco) */}
              {paymentMethod === 'DINHEIRO' && (
                <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-zinc-400 mb-1">
                      Valor Recebido do Cliente (Kz):
                    </label>
                    <input
                      type="number"
                      value={cashReceived}
                      onChange={(e) => setCashReceived(e.target.value)}
                      className="w-full px-3 py-2.5 bg-zinc-950 border border-zinc-700 rounded-lg text-lg font-bold text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  {/* Fast Bills shortcuts */}
                  <div className="flex flex-wrap gap-1.5">
                    {[cartTotal, cartTotal + 1000, cartTotal + 2000, 5000, 10000, 20000]
                      .filter((v, idx, arr) => v >= cartTotal && arr.indexOf(v) === idx)
                      .slice(0, 5)
                      .map((val) => (
                        <button
                          key={val}
                          type="button"
                          onClick={() => setCashReceived(String(val))}
                          className="px-2.5 py-1 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
                        >
                          +{formatKz(val)}
                        </button>
                      ))}
                  </div>

                  {/* Calculated Change */}
                  <div className="flex items-center justify-between pt-2 border-t border-zinc-800">
                    <span className="text-sm font-semibold text-zinc-300">Troco a Devolver:</span>
                    <span className="text-lg font-black text-amber-400">
                      {formatKz(calculatedChange)}
                    </span>
                  </div>
                </div>
              )}

              {/* Customer Details */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="block font-medium text-zinc-400 mb-1">Nome do Cliente:</label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Consumidor Final"
                    className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-200 text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block font-medium text-zinc-400 mb-1">NIF do Cliente:</label>
                  <input
                    type="text"
                    value={customerNif}
                    onChange={(e) => setCustomerNif(e.target.value)}
                    placeholder="999999999"
                    className="w-full px-3 py-2 bg-zinc-900 border border-zinc-800 rounded-lg text-zinc-200 text-xs focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Error Banner */}
              {checkoutError && (
                <div className="p-3 rounded-lg bg-rose-950/80 border border-rose-700 text-rose-300 text-xs flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>{checkoutError}</span>
                </div>
              )}
            </div>

            {/* Modal Footer */}
            <div className="p-4 bg-[#0e131b] border-t border-zinc-800 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsCheckoutOpen(false)}
                className="px-4 py-2.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-semibold"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleFinishSale}
                className="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold shadow-lg shadow-emerald-950 flex items-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Confirmar e Finalizar Venda</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* COMPLETED SALE RECEIPT MODAL */}
      {completedSale && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="bg-[#111620] border border-zinc-700 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl flex flex-col max-h-[95vh]">
            <div className="p-4 bg-[#0e131b] border-b border-zinc-800 flex items-center justify-between">
              <div className="flex items-center gap-2 text-emerald-400">
                <CheckCircle2 className="w-5 h-5" />
                <h3 className="text-base font-bold text-white">Venda Concluída com Sucesso!</h3>
              </div>
              <button
                type="button"
                onClick={() => setCompletedSale(null)}
                className="text-zinc-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Printable Thermal Receipt Style */}
            <div className="p-5 overflow-y-auto">
              <div
                id="receipt-print-area"
                className="bg-white text-zinc-950 p-5 rounded-lg font-mono text-xs shadow-inner space-y-3"
              >
                {/* Header */}
                <div className="text-center border-b border-zinc-300 pb-3">
                  <h2 className="text-base font-black tracking-tight uppercase">KwanzaPOS Loja Comercial</h2>
                  <p className="text-[10px] text-zinc-600">NIF: 5418029310 | Luanda, Angola</p>
                  <p className="text-[10px] text-zinc-600">Tel: +244 923 000 000</p>
                  <div className="mt-1 font-bold text-xs">VENDA A DINHEIRO / FACTURA SIMPLIFICADA</div>
                  <div className="text-[11px] font-bold text-zinc-800">{completedSale.invoiceNumber}</div>
                </div>

                {/* Metadata */}
                <div className="text-[10px] space-y-0.5 border-b border-zinc-200 pb-2">
                  <div className="flex justify-between">
                    <span>Data/Hora:</span>
                    <span>{formatDateTime(completedSale.createdAt)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Operador:</span>
                    <span>{completedSale.sellerName} ({completedSale.sellerRole})</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Cliente:</span>
                    <span>{completedSale.customerName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>NIF Cliente:</span>
                    <span>{completedSale.customerNif}</span>
                  </div>
                </div>

                {/* Items */}
                <div className="space-y-1 border-b border-zinc-300 pb-2">
                  <div className="flex justify-between font-bold text-[10px] border-b border-zinc-200 pb-1">
                    <span>Item</span>
                    <span>Qtd × P.Unit</span>
                    <span>Total</span>
                  </div>
                  {completedSale.items.map((item, idx) => (
                    <div key={idx} className="flex justify-between text-[10px]">
                      <span className="truncate max-w-[120px]">{item.productName}</span>
                      <span>{item.quantity} × {formatKz(item.unitPrice)}</span>
                      <span className="font-bold">{formatKz(item.total)}</span>
                    </div>
                  ))}
                </div>

                {/* Financial Totals */}
                <div className="space-y-1 text-[11px] border-b border-zinc-300 pb-2">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>{formatKz(completedSale.subtotal)}</span>
                  </div>
                  {completedSale.discountTotal > 0 && (
                    <div className="flex justify-between text-zinc-700">
                      <span>Desconto:</span>
                      <span>-{formatKz(completedSale.discountTotal)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-black text-sm pt-1 border-t border-zinc-300">
                    <span>TOTAL PAGO:</span>
                    <span>{formatKz(completedSale.total)}</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-zinc-700">
                    <span>Forma de Pagamento:</span>
                    <span>{getPaymentMethodName(completedSale.payments[0]?.method || 'DINHEIRO')}</span>
                  </div>
                  {completedSale.change > 0 && (
                    <div className="flex justify-between font-bold text-xs text-zinc-900">
                      <span>Troco:</span>
                      <span>{formatKz(completedSale.change)}</span>
                    </div>
                  )}
                </div>

                {/* Footer Disclaimer according to Angolan AGT standard */}
                <div className="text-center text-[9px] text-zinc-500 pt-1 space-y-0.5">
                  <p>Processado por programa validado nº 001/AGT/2026</p>
                  <p>Obrigado pela sua preferência! Volte sempre.</p>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="p-4 bg-[#0e131b] border-t border-zinc-800 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={handlePrintReceipt}
                className="px-4 py-2.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold flex items-center gap-2"
              >
                <Printer className="w-4 h-4" />
                <span>Imprimir Talão</span>
              </button>
              <button
                type="button"
                onClick={() => setCompletedSale(null)}
                className="px-6 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white text-xs font-bold shadow-md flex items-center gap-2"
              >
                <span>Nova Venda</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
