import React, { useMemo, useState } from 'react';
import {
  AlertTriangle,
  ArrowDownRight,
  ArrowLeft,
  ArrowUpRight,
  BarChart3,
  Calendar,
  CheckCircle,
  CreditCard,
  DollarSign,
  FileDown,
  LayoutDashboard,
  PackageX,
  PieChart,
  Plus,
  Receipt,
  Trash2,
  TrendingDown,
  TrendingUp,
  Wallet,
  X,
  Zap,
} from 'lucide-react';
import { Expense, ExpenseCategory, Product, Sale, User } from '../types';
import { formatDateTime, formatDateShort, formatKz, getExpenseCategoryLabel, getPaymentMethodName } from '../lib/formatters';
import { addExpense, deleteExpense, getExpenses } from '../lib/storage';

interface AnalyticsDashboardProps {
  currentUser: User;
  sales: Sale[];
  products: Product[];
  expenses: Expense[];
  onRefreshData: () => void;
  onBackToPDV: () => void;
  onExportPDF: () => void;
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  currentUser,
  sales,
  products,
  expenses,
  onRefreshData,
  onBackToPDV,
  onExportPDF,
}) => {
  const [period, setPeriod] = useState<'HOJE' | 'SEMANA' | 'MES' | 'TUDO'>('TUDO');

  // Expense modal state
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState<boolean>(false);
  const [expenseDesc, setExpenseDesc] = useState<string>('');
  const [expenseCategory, setExpenseCategory] = useState<ExpenseCategory>('FIXA');
  const [expenseAmount, setExpenseAmount] = useState<string>('');
  const [expenseDate, setExpenseDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [expenseError, setExpenseError] = useState<string | null>(null);

  // Filter sales and expenses by period
  const { filteredSales, filteredExpenses } = useMemo(() => {
    const now = new Date();
    const todayStr = now.toISOString().split('T')[0];

    let salesList = sales.filter((s) => s.status === 'CONCLUIDA');
    let expList = expenses;

    if (period === 'HOJE') {
      salesList = salesList.filter((s) => s.createdAt.startsWith(todayStr));
      expList = expList.filter((e) => e.date === todayStr);
    } else if (period === 'SEMANA') {
      const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      salesList = salesList.filter((s) => new Date(s.createdAt) >= sevenDaysAgo);
      expList = expList.filter((e) => new Date(e.date) >= sevenDaysAgo);
    } else if (period === 'MES') {
      const currentMonthStr = todayStr.substring(0, 7);
      salesList = salesList.filter((s) => s.createdAt.startsWith(currentMonthStr));
      expList = expList.filter((e) => e.date.startsWith(currentMonthStr));
    }

    return { filteredSales: salesList, filteredExpenses: expList };
  }, [sales, expenses, period]);

  // Financial Metrics
  const metrics = useMemo(() => {
    const faturamentoBruto = filteredSales.reduce((sum, s) => sum + s.total, 0);
    const custoVendasCMV = filteredSales.reduce((sum, s) => sum + s.totalCost, 0);
    const lucroBruto = Math.max(0, faturamentoBruto - custoVendasCMV);
    const totalDespesasPerdas = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
    const lucroLiquidoReal = lucroBruto - totalDespesasPerdas;

    const margemBrutaPercent = faturamentoBruto > 0 ? ((lucroBruto / faturamentoBruto) * 100).toFixed(1) : '0';
    const margemLiquidaPercent = faturamentoBruto > 0 ? ((lucroLiquidoReal / faturamentoBruto) * 100).toFixed(1) : '0';

    const countVendas = filteredSales.length;
    const ticketMedio = countVendas > 0 ? Math.round(faturamentoBruto / countVendas) : 0;

    return {
      faturamentoBruto,
      custoVendasCMV,
      lucroBruto,
      totalDespesasPerdas,
      lucroLiquidoReal,
      margemBrutaPercent,
      margemLiquidaPercent,
      countVendas,
      ticketMedio,
    };
  }, [filteredSales, filteredExpenses]);

  // Sales by payment method
  const paymentBreakdown = useMemo(() => {
    const totals: Record<string, number> = {
      MULTICAIXA: 0,
      DINHEIRO: 0,
      TRANSFERENCIA: 0,
      MISTO: 0,
    };

    filteredSales.forEach((s) => {
      s.payments.forEach((p) => {
        totals[p.method] = (totals[p.method] || 0) + p.amount;
      });
    });

    const total = Object.values(totals).reduce((a, b) => a + b, 0);

    return Object.entries(totals).map(([method, amount]) => ({
      method,
      amount,
      percentage: total > 0 ? Math.round((amount / total) * 100) : 0,
    }));
  }, [filteredSales]);

  // Top Products Sold
  const topProducts = useMemo(() => {
    const map: Record<string, { name: string; quantity: number; revenue: number }> = {};

    filteredSales.forEach((s) => {
      s.items.forEach((item) => {
        if (!map[item.productId]) {
          map[item.productId] = { name: item.productName, quantity: 0, revenue: 0 };
        }
        map[item.productId].quantity += item.quantity;
        map[item.productId].revenue += item.total;
      });
    });

    return Object.values(map)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  }, [filteredSales]);

  const handleSaveExpense = (e: React.FormEvent) => {
    e.preventDefault();
    setExpenseError(null);

    const amount = parseFloat(expenseAmount);
    if (!expenseDesc.trim()) {
      setExpenseError('Informe a descrição da despesa ou perda.');
      return;
    }
    if (isNaN(amount) || amount <= 0) {
      setExpenseError('Informe um valor válido em Kz.');
      return;
    }

    addExpense({
      description: expenseDesc.trim(),
      category: expenseCategory,
      amount,
      date: expenseDate,
      registeredBy: `${currentUser.name} (${currentUser.role})`,
    });

    setIsExpenseModalOpen(false);
    setExpenseDesc('');
    setExpenseAmount('');
    onRefreshData();
  };

  const handleDeleteExpense = (id: string) => {
    if (confirm('Tem certeza que deseja apagar este registo de despesa?')) {
      deleteExpense(id);
      onRefreshData();
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#0a0d14] text-zinc-100 overflow-y-auto">
      {/* Top action header with visible "Voltar ao PDV" and "Exportar Relatório A4" */}
      <div className="bg-[#0e131b] border-b border-zinc-800 p-3 sm:p-5 sticky top-0 z-20 shadow-md">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Back button & Title */}
          <div className="flex items-center gap-3">
            <button
              type="button"
              id="btn-voltar-dashboard"
              onClick={onBackToPDV}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 active:scale-95 text-zinc-100 font-bold text-xs sm:text-sm border border-zinc-700 transition-all shadow-sm"
              title="Voltar para a Frente de Caixa"
            >
              <ArrowLeft className="w-4 h-4 text-emerald-400" />
              <span>Voltar ao PDV</span>
            </button>
            <div>
              <h1 className="text-base sm:text-xl font-black tracking-tight text-white flex items-center gap-2">
                <LayoutDashboard className="w-5 h-5 text-emerald-400" />
                <span>Dashboard Analítico & Financeiro</span>
              </h1>
              <p className="text-xs text-zinc-400 hidden sm:block">
                Faturamento, CMV, Lucro Líquido e Gestão de Despesas/Perdas
              </p>
            </div>
          </div>

          {/* Period selector & A4 Export */}
          <div className="flex items-center gap-2">
            <div className="flex items-center bg-zinc-900 border border-zinc-700/80 rounded-xl p-0.5 text-xs">
              {(['HOJE', 'SEMANA', 'MES', 'TUDO'] as const).map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPeriod(p)}
                  className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                    period === p ? 'bg-emerald-600 text-white shadow-sm' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {p === 'HOJE' ? 'Hoje' : p === 'SEMANA' ? '7 Dias' : p === 'MES' ? 'Mês' : 'Geral'}
                </button>
              ))}
            </div>

            <button
              type="button"
              onClick={onExportPDF}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-emerald-400 border border-emerald-500/30 text-xs font-bold transition-colors"
              title="Exportar Relatório Executivo A4 em PDF"
            >
              <FileDown className="w-4 h-4" />
              <span className="hidden sm:inline">Exportar PDF A4</span>
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl w-full mx-auto p-3 sm:p-6 space-y-6">
        {/* KPI Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
          {/* Total Vendido (Kz) */}
          <div className="p-4 rounded-2xl bg-[#111620] border border-zinc-800 relative overflow-hidden">
            <div className="flex items-center justify-between text-xs text-zinc-400">
              <span className="font-bold text-zinc-300">Total Vendido (Kz)</span>
              <TrendingUp className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-white mt-2">
              {formatKz(metrics.faturamentoBruto)}
            </div>
            <div className="text-[11px] text-zinc-500 mt-1 flex items-center justify-between">
              <span>{metrics.countVendas} vendas no período</span>
              <span>TM: {formatKz(metrics.ticketMedio)}</span>
            </div>
            <div className="absolute bottom-0 inset-x-0 h-1 bg-emerald-500/80" />
          </div>

          {/* Total Custo (Kz) */}
          <div className="p-4 rounded-2xl bg-[#111620] border border-zinc-800 relative overflow-hidden">
            <div className="flex items-center justify-between text-xs text-zinc-400">
              <span className="font-bold text-zinc-300">Total Custo (Kz)</span>
              <ArrowDownRight className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-amber-300 mt-2">
              {formatKz(metrics.custoVendasCMV)}
            </div>
            <div className="text-[11px] text-zinc-500 mt-1">
              Lucro Bruto: <strong className="text-zinc-200">{formatKz(metrics.lucroBruto)}</strong> ({metrics.margemBrutaPercent}%)
            </div>
            <div className="absolute bottom-0 inset-x-0 h-1 bg-amber-500/80" />
          </div>

          {/* Despesas & Perdas (Kz) */}
          <div className="p-4 rounded-2xl bg-[#111620] border border-zinc-800 relative overflow-hidden">
            <div className="flex items-center justify-between text-xs text-zinc-400">
              <span className="font-bold text-zinc-300">Despesas & Perdas (Kz)</span>
              <PackageX className="w-4 h-4 text-rose-400" />
            </div>
            <div className="text-xl sm:text-2xl font-black text-rose-400 mt-2">
              {formatKz(metrics.totalDespesasPerdas)}
            </div>
            <div className="text-[11px] text-zinc-500 mt-1">
              {filteredExpenses.length} registos (Fixas, Variáveis, Salários, Perdas)
            </div>
            <div className="absolute bottom-0 inset-x-0 h-1 bg-rose-500/80" />
          </div>

          {/* Lucro Líquido (Kz) */}
          <div className="p-4 rounded-2xl bg-[#0f1d17] border border-emerald-500/60 relative overflow-hidden shadow-lg shadow-emerald-950/30">
            <div className="flex items-center justify-between text-xs text-emerald-300">
              <span className="font-extrabold uppercase tracking-wider">Lucro Líquido (Kz)</span>
              <Wallet className="w-4 h-4 text-emerald-400" />
            </div>
            <div className={`text-xl sm:text-2xl font-black mt-2 ${metrics.lucroLiquidoReal >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {formatKz(metrics.lucroLiquidoReal)}
            </div>
            <div className="text-[11px] text-emerald-400/80 mt-1 flex items-center justify-between">
              <span>Margem Líquida Real:</span>
              <span className="font-bold">{metrics.margemLiquidaPercent}%</span>
            </div>
            <div className="absolute bottom-0 inset-x-0 h-1 bg-emerald-400" />
          </div>
        </div>

        {/* Charts and Breakdown Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Visual Financial Comparison Bar Chart */}
          <div className="lg:col-span-2 p-5 rounded-2xl bg-[#0e131b] border border-zinc-800 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-emerald-400" />
                  <span>Demonstrativo Financeiro (Kz)</span>
                </h3>
                <p className="text-xs text-zinc-400">
                  Comparação direta entre Faturamento, Custos CMV, Despesas e Lucro Líquido
                </p>
              </div>
            </div>

            {/* Custom High-Quality SVG Visual Bars */}
            <div className="space-y-4 pt-2">
              {/* Faturamento bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-zinc-300 font-medium">Faturamento Total das Vendas</span>
                  <span className="font-bold text-white">{formatKz(metrics.faturamentoBruto)}</span>
                </div>
                <div className="w-full h-5 bg-zinc-900 rounded-lg overflow-hidden border border-zinc-800">
                  <div className="h-full bg-emerald-500 rounded-lg transition-all duration-700" style={{ width: '100%' }} />
                </div>
              </div>

              {/* Custos CMV bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-zinc-300 font-medium">Custo Mercadorias Vendidas (CMV)</span>
                  <span className="font-bold text-amber-400">{formatKz(metrics.custoVendasCMV)}</span>
                </div>
                <div className="w-full h-5 bg-zinc-900 rounded-lg overflow-hidden border border-zinc-800">
                  <div
                    className="h-full bg-amber-500/90 rounded-lg transition-all duration-700"
                    style={{
                      width: `${metrics.faturamentoBruto > 0 ? (metrics.custoVendasCMV / metrics.faturamentoBruto) * 100 : 0}%`,
                    }}
                  />
                </div>
              </div>

              {/* Despesas/Perdas bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-zinc-300 font-medium">Despesas Operacionais & Avarias</span>
                  <span className="font-bold text-rose-400">{formatKz(metrics.totalDespesasPerdas)}</span>
                </div>
                <div className="w-full h-5 bg-zinc-900 rounded-lg overflow-hidden border border-zinc-800">
                  <div
                    className="h-full bg-rose-500/90 rounded-lg transition-all duration-700"
                    style={{
                      width: `${metrics.faturamentoBruto > 0 ? Math.min(100, (metrics.totalDespesasPerdas / metrics.faturamentoBruto) * 100) : 0}%`,
                    }}
                  />
                </div>
              </div>

              {/* Lucro Líquido Real bar */}
              <div>
                <div className="flex justify-between text-xs mb-1">
                  <span className="text-emerald-400 font-bold">Resultado Líquido Real</span>
                  <span className="font-black text-emerald-400">{formatKz(metrics.lucroLiquidoReal)}</span>
                </div>
                <div className="w-full h-5 bg-zinc-900 rounded-lg overflow-hidden border border-zinc-800">
                  <div
                    className="h-full bg-emerald-400 rounded-lg transition-all duration-700 shadow-sm"
                    style={{
                      width: `${metrics.faturamentoBruto > 0 ? Math.max(0, (metrics.lucroLiquidoReal / metrics.faturamentoBruto) * 100) : 0}%`,
                    }}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Payment Methods Breakdown */}
          <div className="p-5 rounded-2xl bg-[#0e131b] border border-zinc-800 space-y-4">
            <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-emerald-400" />
              <span>Meios de Pagamento</span>
            </h3>

            <div className="space-y-3 pt-1">
              {paymentBreakdown.map((item) => (
                <div key={item.method} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-zinc-300 font-medium">{getPaymentMethodName(item.method)}</span>
                    <span className="font-bold text-zinc-100">{formatKz(item.amount)} ({item.percentage}%)</span>
                  </div>
                  <div className="w-full h-2.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                    <div
                      className={`h-full rounded-full ${
                        item.method === 'MULTICAIXA'
                          ? 'bg-emerald-500'
                          : item.method === 'DINHEIRO'
                          ? 'bg-blue-500'
                          : item.method === 'TRANSFERENCIA'
                          ? 'bg-amber-400'
                          : 'bg-purple-500'
                      }`}
                      style={{ width: `${item.percentage}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Top Products mini list */}
            <div className="pt-3 border-t border-zinc-800">
              <h4 className="text-xs font-bold text-zinc-300 mb-2">Top 5 Produtos Mais Vendidos</h4>
              <div className="space-y-2">
                {topProducts.map((p, idx) => (
                  <div key={idx} className="flex justify-between items-center text-xs">
                    <span className="text-zinc-400 truncate max-w-[150px]">
                      {idx + 1}. {p.name}
                    </span>
                    <span className="font-semibold text-emerald-400">{formatKz(p.revenue)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* MÓDULO DE CONTROLE DE DESPESAS E PERDAS */}
        <div className="p-5 rounded-2xl bg-[#0e131b] border border-zinc-800 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                <PackageX className="w-4 h-4 text-rose-400" />
                <span>Gestão de Despesas & Perdas Operacionais</span>
              </h3>
              <p className="text-xs text-zinc-400">
                Registe quebras, produtos com prazo vencido e custos operacionais que abatem o lucro líquido
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                setExpenseError(null);
                setExpenseDesc('');
                setExpenseAmount('');
                setIsExpenseModalOpen(true);
              }}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-rose-950/70 border border-rose-700/80 hover:bg-rose-900/60 text-rose-300 text-xs font-bold transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Registar Nova Despesa / Perda</span>
            </button>
          </div>

          {/* Category Summary Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-1">
            {(['FIXA', 'VARIAVEL', 'SALARIO', 'PERDA'] as const).map((cat) => {
              const catExpenses = expenses.filter((e) => e.category === cat);
              const catTotal = catExpenses.reduce((sum, e) => sum + e.amount, 0);
              const info = getExpenseCategoryLabel(cat);
              return (
                <div key={cat} className={`p-3 rounded-xl border ${info.bg} ${info.border}`}>
                  <div className="text-[11px] font-bold text-zinc-400">{info.label}</div>
                  <div className={`text-sm sm:text-base font-black mt-1 ${info.color}`}>
                    {formatKz(catTotal)}
                  </div>
                  <div className="text-[10px] text-zinc-500 mt-0.5">
                    {catExpenses.length} {catExpenses.length === 1 ? 'lançamento' : 'lançamentos'}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Expenses Table */}
          <div className="overflow-x-auto rounded-xl border border-zinc-800">
            <table className="w-full text-left text-xs">
              <thead className="bg-zinc-900 text-zinc-400 uppercase text-[10px] tracking-wider border-b border-zinc-800">
                <tr>
                  <th className="p-3">Data</th>
                  <th className="p-3">Descrição da Despesa/Perda</th>
                  <th className="p-3">Categoria</th>
                  <th className="p-3">Registado Por</th>
                  <th className="p-3 text-right">Valor em Kz</th>
                  <th className="p-3 text-right">Ação</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60">
                {expenses.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-6 text-center text-zinc-500">
                      Nenhuma despesa ou perda registada até ao momento.
                    </td>
                  </tr>
                ) : (
                  expenses.map((exp) => (
                    <tr key={exp.id} className="hover:bg-zinc-900/40 transition-colors">
                      <td className="p-3 text-zinc-400">{exp.date}</td>
                      <td className="p-3 font-semibold text-zinc-200">{exp.description}</td>
                      <td className="p-3">
                        {(() => {
                          const info = getExpenseCategoryLabel(exp.category);
                          return (
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${info.bg} ${info.color} ${info.border}`}>
                              {info.label}
                            </span>
                          );
                        })()}
                      </td>
                      <td className="p-3 text-zinc-400 text-[11px]">{exp.registeredBy}</td>
                      <td className="p-3 text-right font-bold text-rose-400">
                        -{formatKz(exp.amount)}
                      </td>
                      <td className="p-3 text-right">
                        <button
                          type="button"
                          onClick={() => handleDeleteExpense(exp.id)}
                          className="p-1 text-zinc-500 hover:text-rose-400 transition-colors"
                          title="Remover despesa"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* REGISTER EXPENSE / LOSS MODAL */}
      {isExpenseModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
          <div className="bg-[#111620] border border-zinc-700 rounded-2xl w-full max-w-md overflow-hidden shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-3">
              <h3 className="font-bold text-sm text-white flex items-center gap-2">
                <PackageX className="w-4 h-4 text-rose-400" />
                <span>Registar Despesa ou Perda</span>
              </h3>
              <button
                type="button"
                onClick={() => setIsExpenseModalOpen(false)}
                className="text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveExpense} className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-zinc-300 mb-1">Descrição do Ocorrido *</label>
                <input
                  type="text"
                  required
                  value={expenseDesc}
                  onChange={(e) => setExpenseDesc(e.target.value)}
                  placeholder="Ex: 2 garrafas partidas no manuseio, conta de luz ENDE..."
                  className="w-full px-3 py-2 bg-zinc-900 border border-zinc-700 rounded-lg text-zinc-100 focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-zinc-300 mb-1">Categoria *</label>
                  <select
                    value={expenseCategory}
                    onChange={(e) => setExpenseCategory(e.target.value as ExpenseCategory)}
                    className="w-full px-3 py-2 bg-zinc-900 border border-zinc-700 rounded-lg text-zinc-200 focus:outline-none"
                  >
                    <option value="FIXA">Fixa (Aluguer, Renda, Internet)</option>
                    <option value="VARIAVEL">Variável (Energia, Água, Transporte)</option>
                    <option value="SALARIO">Salário (Equipa & Comissões)</option>
                    <option value="PERDA">Perda (Avaria, Quebra, Validade)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-rose-400 mb-1">Valor em Kz *</label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={expenseAmount}
                    onChange={(e) => setExpenseAmount(e.target.value)}
                    placeholder="Ex: 15000"
                    className="w-full px-3 py-2 bg-zinc-900 border border-zinc-700 rounded-lg text-zinc-100 font-bold focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-zinc-300 mb-1">Data do Ocorrido</label>
                <input
                  type="date"
                  value={expenseDate}
                  onChange={(e) => setExpenseDate(e.target.value)}
                  className="w-full px-3 py-2 bg-zinc-900 border border-zinc-700 rounded-lg text-zinc-200 focus:outline-none"
                />
              </div>

              {expenseError && (
                <div className="p-2.5 rounded-lg bg-rose-950/80 border border-rose-700 text-rose-300 text-xs">
                  {expenseError}
                </div>
              )}

              <div className="pt-2 border-t border-zinc-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsExpenseModalOpen(false)}
                  className="px-3 py-1.5 bg-zinc-800 text-zinc-300 rounded-lg"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-rose-600 hover:bg-rose-500 active:scale-95 text-white font-bold rounded-lg"
                >
                  Registar Despesa
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
