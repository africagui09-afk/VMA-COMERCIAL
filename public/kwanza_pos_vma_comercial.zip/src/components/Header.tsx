import React, { useEffect, useState } from 'react';
import {
  ArrowLeft,
  Cloud,
  CloudOff,
  Database,
  Layers,
  LayoutDashboard,
  LogOut,
  Package,
  RefreshCw,
  RotateCcw,
  ShieldCheck,
  ShoppingCart,
  UserCheck,
  Users,
  Wifi,
  WifiOff,
} from 'lucide-react';
import { User } from '../types';
import { formatKz, getRoleBadgeInfo } from '../lib/formatters';
import { getProducts, getSellerDailyTotal, getSyncQueue, getUnsyncedSales, SELLER_DAILY_LIMIT } from '../lib/storage';
import { batchSyncSalesToSupabase, forceImmediateBatchSync } from '../lib/supabase';

interface HeaderProps {
  currentUser: User;
  activeView: 'pdv' | 'estoque' | 'dashboard' | 'vendas';
  onNavigate: (view: 'pdv' | 'estoque' | 'dashboard' | 'vendas') => void;
  onOpenLogin: () => void;
  onOpenSupabaseModal: () => void;
  onExportPDF: () => void;
  stockAlertCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  activeView,
  onNavigate,
  onOpenLogin,
  onOpenSupabaseModal,
  onExportPDF,
  stockAlertCount,
}) => {
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [syncCount, setSyncCount] = useState<number>(0);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [dailySales, setDailySales] = useState<number>(0);

  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      triggerSync();
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const updateStats = () => {
      const queueCount = getSyncQueue().length;
      const unsyncedSalesCount = getUnsyncedSales().length;
      setSyncCount(Math.max(queueCount, unsyncedSalesCount));
      if (currentUser.role === 'VENDEDOR') {
        setDailySales(getSellerDailyTotal(currentUser.id));
      }
    };

    const triggerSync = async () => {
      setIsSyncing(true);
      try {
        await batchSyncSalesToSupabase();
      } catch (err) {
        console.warn('Sincronização em lote background falhou:', err);
      } finally {
        setIsSyncing(false);
        updateStats();
      }
    };

    // Force immediate execution of batch background sync
    triggerSync();

    const interval = setInterval(() => {
      updateStats();
    }, 2000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [currentUser]);

  const handleQuickSync = async () => {
    if (isSyncing) return;
    setIsSyncing(true);
    try {
      await forceImmediateBatchSync();
    } finally {
      setIsSyncing(false);
      const queueCount = getSyncQueue().length;
      const unsyncedSalesCount = getUnsyncedSales().length;
      setSyncCount(Math.max(queueCount, unsyncedSalesCount));
    }
  };

  const roleInfo = getRoleBadgeInfo(currentUser.role);
  const sellerLimitPercentage = Math.min(100, Math.round((dailySales / SELLER_DAILY_LIMIT) * 100));

  return (
    <header className="sticky top-0 z-40 bg-[#0e131b] border-b border-zinc-800 text-zinc-100 shadow-lg">
      {/* Top status & information bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-2 text-xs border-b border-zinc-800/60">
        {/* Left: Online Status & Sync Queue */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onOpenSupabaseModal}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full border transition-all ${
              isOnline
                ? 'bg-emerald-950/40 border-emerald-700/60 text-emerald-400 hover:bg-emerald-900/40'
                : 'bg-amber-950/40 border-amber-700/60 text-amber-400 hover:bg-amber-900/40'
            }`}
            title="Clique para configurar o Supabase e sincronização"
          >
            {isOnline ? <Wifi className="w-3.5 h-3.5 text-emerald-400 animate-pulse" /> : <WifiOff className="w-3.5 h-3.5 text-amber-400" />}
            <span className="font-semibold">{isOnline ? 'Online' : 'Modo Offline'}</span>
            <span className="text-[10px] text-zinc-400 opacity-80">(Supabase)</span>
          </button>

          {/* Sync status with green light indicator */}
          <button
            type="button"
            onClick={handleQuickSync}
            disabled={isSyncing}
            id="btn-sync-supabase-header"
            className={`flex items-center gap-2 px-2.5 py-1 rounded-md border transition-all cursor-pointer ${
              isSyncing
                ? 'bg-zinc-800/80 border-emerald-600/50 text-emerald-300'
                : syncCount > 0
                ? 'bg-amber-950/40 border-amber-600/60 text-amber-300 hover:bg-amber-900/40'
                : 'bg-emerald-950/30 border-emerald-700/50 text-emerald-400 hover:bg-emerald-900/30'
            }`}
            title={
              syncCount > 0
                ? 'Vendas pendentes de sincronização. Clique para forçar a sincronização em lote agora!'
                : 'Todas as vendas locais sincronizadas com a nuvem Supabase.'
            }
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-emerald-400' : 'text-emerald-400'}`} />
            {isSyncing ? (
              <span className="flex items-center gap-1.5 text-xs text-emerald-300">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                <span>Sincronizando lote...</span>
              </span>
            ) : syncCount > 0 ? (
              <span className="flex items-center gap-1.5 text-xs text-amber-300 font-bold">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-80"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                </span>
                <span>{syncCount} pendente{syncCount > 1 ? 's' : ''}</span>
              </span>
            ) : (
              /* ESTADO VISUAL: "Dados Sincronizados" com a luz verde */
              <span className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-60"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500 shadow-sm shadow-emerald-500/80"></span>
                </span>
                <span>Dados Sincronizados</span>
              </span>
            )}
          </button>
        </div>

        {/* Center / Right: Vendedor Daily Limit Meter (900.000 Kz) */}
        {currentUser.role === 'VENDEDOR' ? (
          <div className="flex items-center gap-2 bg-zinc-900/90 px-3 py-1 rounded-lg border border-zinc-700/60">
            <span className="text-zinc-400 hidden sm:inline">Limite Diário PDV:</span>
            <span className="font-bold text-emerald-400">{formatKz(dailySales)}</span>
            <span className="text-zinc-500">/ 900.000 Kz</span>
            <div className="w-16 sm:w-24 h-2 bg-zinc-800 rounded-full overflow-hidden ml-1">
              <div
                className={`h-full rounded-full transition-all duration-500 ${
                  sellerLimitPercentage >= 90
                    ? 'bg-rose-500'
                    : sellerLimitPercentage >= 70
                    ? 'bg-amber-400'
                    : 'bg-emerald-500'
                }`}
                style={{ width: `${sellerLimitPercentage}%` }}
              />
            </div>
            <span className="text-[10px] font-semibold text-zinc-400">{sellerLimitPercentage}%</span>
          </div>
        ) : (
          <div className="hidden sm:flex items-center gap-2 text-zinc-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>Sessão ativa com privilégios de <strong className="text-zinc-200">{roleInfo.label}</strong></span>
          </div>
        )}

        {/* User profile & fast switcher */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onOpenLogin}
            className="flex items-center gap-2 px-2.5 py-1 rounded-md bg-zinc-900 hover:bg-zinc-800 border border-zinc-700 text-zinc-200 transition-colors"
            title="Trocar operador ou nível de acesso"
          >
            <div className="w-5 h-5 rounded-full bg-emerald-600/30 text-emerald-400 flex items-center justify-center font-bold text-xs">
              {currentUser.name.charAt(0)}
            </div>
            <span className="font-medium truncate max-w-[110px] sm:max-w-[150px]">{currentUser.name}</span>
            <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded border ${roleInfo.bg} ${roleInfo.color} ${roleInfo.border}`}>
              {currentUser.role}
            </span>
            <span className="text-[10px] text-zinc-400 underline">Alterar</span>
          </button>
        </div>
      </div>

      {/* Main navigation row */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 py-2.5 flex items-center justify-between gap-3">
        {/* Brand & Prominent "Voltar" Button */}
        <div className="flex items-center gap-3">
          {/* Prominent Back Button if not on default PDV screen */}
          {activeView !== 'pdv' ? (
            <button
              type="button"
              id="btn-voltar-principal"
              onClick={() => onNavigate('pdv')}
              className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-semibold text-sm shadow-md transition-all border border-emerald-400/40"
              title="Voltar para a Frente de Caixa"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Voltar ao PDV</span>
            </button>
          ) : (
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-emerald-400 flex items-center justify-center text-zinc-950 font-black shadow-md shadow-emerald-950">
                <ShoppingCart className="w-5 h-5 text-zinc-950" />
              </div>
              <div>
                <h1 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center gap-1.5">
                  Kwanza<span className="text-emerald-400">POS</span>
                  <span className="text-[10px] font-normal px-1.5 py-0.2 rounded bg-zinc-800 text-zinc-400 border border-zinc-700">AO (Kz)</span>
                </h1>
                <p className="text-[11px] text-zinc-400 hidden sm:block">Frente de Caixa & Gestão Comercial</p>
              </div>
            </div>
          )}
        </div>

        {/* View Navigation Tabs */}
        <nav className="flex items-center gap-1 sm:gap-2">
          {/* PDV Tab */}
          <button
            type="button"
            onClick={() => onNavigate('pdv')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
              activeView === 'pdv'
                ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/50 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/70'
            }`}
          >
            <ShoppingCart className="w-4 h-4" />
            <span>Frente de Caixa</span>
          </button>

          {/* Estoque Tab - Accessible to GERENTE and ADMINISTRADOR */}
          {currentUser.role !== 'VENDEDOR' && (
            <button
              type="button"
              onClick={() => onNavigate('estoque')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all relative ${
                activeView === 'estoque'
                  ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/50 shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/70'
              }`}
            >
              <Package className="w-4 h-4" />
              <span>Estoque</span>
              {stockAlertCount > 0 && (
                <span
                  className="bg-rose-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full border border-rose-400 animate-pulse"
                  title={`${stockAlertCount} produtos abaixo do estoque mínimo!`}
                >
                  {stockAlertCount}
                </span>
              )}
            </button>
          )}

          {/* Vendas / Fecho de Caixa Tab */}
          <button
            type="button"
            onClick={() => onNavigate('vendas')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
              activeView === 'vendas'
                ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/50 shadow-sm'
                : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/70'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
            <span className="hidden sm:inline">Histórico & Vendas</span>
            <span className="sm:hidden">Vendas</span>
          </button>

          {/* Dashboard Tab - ADMINISTRADOR only */}
          {currentUser.role === 'ADMINISTRADOR' && (
            <button
              type="button"
              onClick={() => onNavigate('dashboard')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm font-semibold transition-all ${
                activeView === 'dashboard'
                  ? 'bg-emerald-600/20 text-emerald-300 border border-emerald-500/50 shadow-sm'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/70'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              <span className="hidden md:inline">Dashboard Analítico</span>
              <span className="md:hidden">Dashboard</span>
            </button>
          )}

          {/* PDF Report Export Quick Button */}
          {currentUser.role !== 'VENDEDOR' && (
            <button
              type="button"
              onClick={onExportPDF}
              className="hidden lg:flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-semibold bg-zinc-800 hover:bg-zinc-700 text-zinc-300 border border-zinc-700 transition-colors ml-1"
              title="Gerar e imprimir relatório formal em formato A4"
            >
              <span>Relatório A4</span>
            </button>
          )}
        </nav>
      </div>
    </header>
  );
};
