import React, { useState } from 'react';
import {
  Check,
  CheckCircle2,
  KeyRound,
  Lock,
  LogOut,
  Shield,
  ShieldAlert,
  ShieldCheck,
  UserCheck,
  Users,
  X,
} from 'lucide-react';
import { User, UserRole } from '../types';
import { DEFAULT_USERS, setCurrentUser } from '../lib/storage';
import { getRoleBadgeInfo } from '../lib/formatters';

interface LoginModalProps {
  currentUser: User;
  onSelectUser: (user: User) => void;
  onClose: () => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  currentUser,
  onSelectUser,
  onClose,
}) => {
  const [selectedRole, setSelectedRole] = useState<UserRole>(currentUser.role);
  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);

  const handleQuickSwitch = (user: User) => {
    setCurrentUser(user);
    onSelectUser(user);
    onClose();
  };

  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPinError(null);

    const targetUser = DEFAULT_USERS.find((u) => u.role === selectedRole);
    if (!targetUser) return;

    if (pinInput && pinInput !== targetUser.pin) {
      setPinError(`PIN incorreto para ${targetUser.name}. (Dica: o PIN padrão é ${targetUser.pin})`);
      return;
    }

    handleQuickSwitch(targetUser);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-[#111620] border border-zinc-700 rounded-2xl w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 bg-[#0e131b] border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-bold text-white">Autenticação & Níveis de Acesso</h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-zinc-400 hover:text-white p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-5 text-xs">
          <div>
            <p className="text-zinc-400">
              Alterne rapidamente entre os perfis do sistema para testar as permissões e restrições de cada nível de acesso.
            </p>
          </div>

          {/* 3 Role Profiles Cards */}
          <div className="space-y-3">
            {DEFAULT_USERS.map((user) => {
              const isCurrent = currentUser.id === user.id;
              const roleInfo = getRoleBadgeInfo(user.role);

              return (
                <div
                  key={user.id}
                  onClick={() => handleQuickSwitch(user)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                    isCurrent
                      ? 'bg-[#0f1d16] border-emerald-500 shadow-md shadow-emerald-950/40'
                      : 'bg-[#151b26] border-zinc-800 hover:border-zinc-600 hover:bg-[#192130]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center font-black text-sm text-zinc-200">
                      {user.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-white text-sm">{user.name}</span>
                        <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded border ${roleInfo.bg} ${roleInfo.color} ${roleInfo.border}`}>
                          {user.role}
                        </span>
                      </div>
                      <p className="text-[11px] text-zinc-400 mt-0.5">
                        {user.role === 'VENDEDOR' && (
                          <span>Apenas Frente de Caixa • Limite diário de <strong>900.000 Kz</strong></span>
                        )}
                        {user.role === 'GERENTE' && (
                          <span>PDV + Estoque • Cancelamentos permitidos até <strong>1 hora</strong></span>
                        )}
                        {user.role === 'ADMINISTRADOR' && (
                          <span className="text-emerald-400/90 font-medium">Acesso Total: PDV, Estoque, Dashboard Financeiro & Relatórios</span>
                        )}
                      </p>
                      <div className="text-[10px] text-zinc-500 mt-1">
                        PIN de acesso: <span className="font-mono text-zinc-400">{user.pin}</span>
                      </div>
                    </div>
                  </div>

                  <div className="self-end sm:self-center">
                    {isCurrent ? (
                      <span className="flex items-center gap-1 text-emerald-400 font-bold text-xs bg-emerald-950/60 px-2.5 py-1 rounded-full border border-emerald-800">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        Ativo
                      </span>
                    ) : (
                      <button
                        type="button"
                        className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold"
                      >
                        Entrar com este perfil
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick PIN login form */}
          <div className="p-4 rounded-xl bg-zinc-900/60 border border-zinc-800 space-y-3">
            <div className="flex items-center gap-2 text-zinc-300 font-bold">
              <KeyRound className="w-4 h-4 text-emerald-400" />
              <span>Entrada Rápida por PIN Numérico</span>
            </div>

            <form onSubmit={handlePinSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-zinc-400 mb-1">Selecionar Nível:</label>
                  <select
                    value={selectedRole}
                    onChange={(e) => setSelectedRole(e.target.value as UserRole)}
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-700 rounded-lg text-zinc-200 focus:outline-none"
                  >
                    <option value="VENDEDOR">Vendedor (PIN: 1111)</option>
                    <option value="GERENTE">Gerente (PIN: 2222)</option>
                    <option value="ADMINISTRADOR">Administrador (PIN: 1234)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-zinc-400 mb-1">Digitar PIN:</label>
                  <input
                    type="password"
                    maxLength={6}
                    value={pinInput}
                    onChange={(e) => setPinInput(e.target.value)}
                    placeholder="****"
                    className="w-full px-3 py-2 bg-zinc-950 border border-zinc-700 rounded-lg text-white tracking-widest font-mono text-center focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {pinError && (
                <div className="p-2 rounded bg-rose-950/80 border border-rose-800 text-rose-300 text-xs">
                  {pinError}
                </div>
              )}

              <button
                type="submit"
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg transition-colors shadow-md"
              >
                Validar PIN e Iniciar Turno
              </button>
            </form>
          </div>
        </div>

        <div className="p-4 bg-[#0e131b] border-t border-zinc-800 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg text-xs font-semibold"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
